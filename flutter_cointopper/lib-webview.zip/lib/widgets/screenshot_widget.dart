import 'package:flutter/material.dart';
import 'dart:ui' as ui;
import 'dart:typed_data';
import 'package:flutter/rendering.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:image_picker_saver/image_picker_saver.dart';
import 'package:intl/intl.dart';

class ScreenShotWidget extends StatefulWidget {
  final data;
  final currencySymbol;
  ScreenShotWidget(this.data, this.currencySymbol);
  @override
  _ScreenShotWidgetState createState() => _ScreenShotWidgetState();
}

class _ScreenShotWidgetState extends State<ScreenShotWidget> {
  GlobalKey _globalKey = new GlobalKey();

  Future<void> _captureScreenshot(_globalKey, var data) async {
    try {
      RenderRepaintBoundary boundary =
          _globalKey.currentContext.findRenderObject();
      ui.Image image = await boundary.toImage();
      ByteData byteData =
          await image.toByteData(format: ui.ImageByteFormat.png);
      var png = byteData.buffer.asUint8List();
      final snackBar = SnackBar(
        content: Text('Saved to Gallery'),
        backgroundColor: Colors.green,
        action: SnackBarAction(
          label: 'Ok',
          onPressed: () {
            // Some code
          },
        ),
      ); 
      
      var filePath = await ImagePickerSaver.saveFile(
          fileData: byteData.buffer.asUint8List());
      print(filePath);
      Scaffold.of(context).showSnackBar(snackBar);
      Navigator.of(context).pop();
    } catch (e) {
      print(e);
    }
  }

  Widget _openPopup(var data, String currencySymbol) {
    Widget share = FlatButton(
      child: Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: Colors.white30,
          ),
          child: Icon(
            Icons.share,
            color: Colors.white,
          )),
      onPressed: () {},
    );
    Widget download = FlatButton(
      child: Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: Colors.white30,
          ),
          child: Icon(
            Icons.arrow_downward,
            color: Colors.white,
          )),
      onPressed: () {
        FocusScope.of(context).requestFocus(FocusNode());
        _captureScreenshot(_globalKey, data);
      },
    );
    Widget close = FlatButton(
      child: Container(
          padding: EdgeInsets.all(10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: Colors.white30,
          ),
          child: Icon(
            Icons.close,
            color: Colors.white,
          )),
      onPressed: () {
        Navigator.of(context).pop();
      },
    );

    var currDt = DateTime.now();
    String formattedDate = DateFormat('dd MMM yyyy \n kk:mm:ss').format(currDt); 
    AlertDialog alert = AlertDialog(
      actionsOverflowDirection: VerticalDirection.up,
      actionsPadding: EdgeInsets.all(0),
      elevation: 0,
      titlePadding: EdgeInsets.all(0),
      backgroundColor: Colors.transparent,
      contentPadding: EdgeInsets.only(top: 30, left: 30, right: 30, bottom: 0),
      actionsOverflowButtonSpacing: 0,
      buttonPadding: EdgeInsets.all(0),
      insetPadding: EdgeInsets.all(0),
      content: Container(
        height: 180,
        child: new Column(
          children: <Widget>[
            RepaintBoundary(
              key: _globalKey,
              child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 3,
                child: Container(
                  // height: 200,
                  padding: EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    gradient: LinearGradient(
                      begin: Alignment.centerLeft,
                      end: Alignment.centerRight,
                      colors: [HexColor(data.color1), HexColor(data.color2)],
                    ),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: EdgeInsets.all(2),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(30),
                                  color: Colors.white30,
                                ),
                                child: Image(
                                  width: 30,
                                  height: 30,
                                  image: NetworkImage(data.logo),
                                ),
                              ),
                              SizedBox(
                                width: 6,
                              ),
                              Text(
                                "${data.name}/${data.symbol}",
                                style: TextStyle(
                                    fontSize: 18, color: Colors.white60),
                              ),
                            ],
                          ),
                        ],
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            data.price > 99999
                                ? NumberFormat.compactCurrency(
                                    decimalDigits: 2,
                                    symbol: '${widget.currencySymbol}',
                                  ).format(data.price)
                                : '${widget.currencySymbol}' +
                                    data.price.toStringAsFixed(2),
                            style: TextStyle(
                                fontSize: 24,
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Image(
                            height: 10,
                            width: 10,
                            image: AssetImage(data.percent_change24h > 0
                                ? "assets/images/up_arrow.png"
                                : "assets/images/down_arrow.png"),
                          ),
                          SizedBox(
                            width: 5,
                          ),
                          Text(
                            "${data.percent_change24h.toStringAsFixed(2)}%",
                            style: TextStyle(
                                fontSize: 14,
                                color: Colors.white60,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Icon(
                            FontAwesomeIcons.btc,
                            color: Colors.white60,
                            size: 14,
                          ),
                          Text(
                            "${data.price_btc.toStringAsFixed(8)}",
                            style: TextStyle(
                                fontSize: 14,
                                color: Colors.white60,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: MediaQuery.of(context).size.width * 0.4,
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      data.high24_usd > 99999
                                          ? NumberFormat.compactCurrency(
                                              decimalDigits: 2,
                                              symbol:
                                                  '${widget.currencySymbol}',
                                            ).format(data.high24_usd)
                                          : '${widget.currencySymbol}' +
                                              data.high24_usd
                                                  .toStringAsFixed(2),
                                      style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      "24 HOUR HIGH",
                                      style: TextStyle(
                                          fontSize: 8,
                                          color: Colors.white60,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Text(
                                      data.low24_usd > 99999
                                          ? NumberFormat.compactCurrency(
                                              decimalDigits: 2,
                                              symbol:
                                                  '${widget.currencySymbol}',
                                            ).format(data.low24_usd)
                                          : '${widget.currencySymbol}' +
                                              data.low24_usd.toStringAsFixed(2),
                                      style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      "24 HOUR LOW",
                                      style: TextStyle(
                                          fontSize: 8,
                                          color: Colors.white60,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Text(
                                      NumberFormat.compactCurrency(
                                        decimalDigits: 2,
                                        symbol: '$currencySymbol',
                                      ).format(data.market_cap_usd),
                                      style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      "Market Cap",
                                      style: TextStyle(
                                          fontSize: 8,
                                          color: Colors.white60,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: MediaQuery.of(context).size.width * 0.2,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Text(
                                  "$formattedDate ISD",
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: Colors.white60,
                                      fontWeight: FontWeight.bold),
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Image(
                                  width:
                                      MediaQuery.of(context).size.width * 0.2,
                                  image: AssetImage('assets/images/logo.png'),
                                  fit: BoxFit.cover,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "CoinTopper.com",
                                  style: TextStyle(
                                      fontSize: 8,
                                      color: Colors.white60,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      actions: [
        SizedBox(
          width: MediaQuery.of(context).size.width,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              share,
              download,
              close,
            ],
          ),
        )
      ],
    );
    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Center(child: alert);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: () {
        _openPopup(widget.data, widget.currencySymbol);
      },
      icon: Icon(
        Icons.pages,
        color: Colors.white,
      ),
    );
  }
}
