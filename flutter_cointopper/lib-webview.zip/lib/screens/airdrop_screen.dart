import 'package:flutter/material.dart';

class AirdropScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: Text("Airdrop screen Coming soon"),
        ),
      ),
    );
  }
}
