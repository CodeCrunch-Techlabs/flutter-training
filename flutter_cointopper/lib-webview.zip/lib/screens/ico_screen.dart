import 'package:flutter/material.dart';

class IcoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Center(
          child: Text("ICOs Screen Coming soon"),
        ),
      ),
    );
  }
}
