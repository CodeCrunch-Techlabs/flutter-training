class CoinListModel {
  final dynamic percent_change24h;
  final String logo;
  final dynamic price_btc;
  final dynamic price;
  final String symbol;
  final String name;

  CoinListModel(
      {this.percent_change24h,
      this.logo,
      this.price_btc,
      this.price,
      this.symbol,
      this.name});

  static List<CoinListModel> getList() {  
    return <CoinListModel>[
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "eth.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Ethurium ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
      CoinListModel(
        percent_change24h: 4.46,
        logo: "bitcoin.png",
        price_btc: 1,
        price: 9120.78134585,
        symbol: "BTC",
        name: "Bitcoin ",
      ),
    ];
  }
}
